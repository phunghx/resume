from __future__ import print_function

# gym boilerplate
import numpy as np
import gym
from gym import wrappers
from gym.spaces import Discrete, Box

from math import *
import random
import time
import math
#from winfrey import wavegraph
#from rpm import rpm # replay memory implementation
import tensorflow as tf
import canton as ct
from canton import *
from observation_processor import process_observation as po
from observation_processor import generate_observation as go
class nnagent(object):
    def __init__(self,
    observation_space_dims,
    action_space
    ):
        
        self.train_multiplier = 1
        self.observation_stack_factor = 1
        self.inputdims = observation_space_dims * self.observation_stack_factor
        # assume observation_space is continuous
        self.is_continuous = True 
        if self.is_continuous: # if action space is continuous
            low = action_space.low
            high = action_space.high
            num_of_actions = action_space.shape[0]
            self.action_bias = high/2. + low/2.
            self.action_multiplier = high - self.action_bias
            def clamper(actions):
                return np.clip(actions,a_max=action_space.high,a_min=action_space.low)
            self.clamper = clamper
        self.outputdims = num_of_actions
        self.discount_factor = 1
        ids,ods = self.inputdims,self.outputdims
        self.actor = self.create_actor_network(ids,ods)
        self.joint_inference = self.train_step_gen()
        sess = ct.get_session()
        sess.run(tf.global_variables_initializer())
    # the part of network that the input and output shares architechture
    def create_common_network(self,inputdims,outputdims):
        c = Can()
        rect = Act('lrelu',alpha=0.2)
        magic = 1/(0.5 + 0.5*0.2)
        # rect = Act('elu')
        d1 = c.add(Dense(inputdims,256,stddev=magic))
        d1a = c.add(Dense(256,128,stddev=magic))
        d2 = c.add(Dense(128,outputdims,stddev=magic))
        def call(i):
            i = rect(d1(i))
            i = rect(d1a(i))
            i = rect(d2(i))
            return i
        c.set_function(call)
        return c

    # a = actor(s) : predict actions given state
    def create_actor_network(self,inputdims,outputdims):
        # add gaussian noise.
        rect = Act('relu',alpha=0.2)
        magic = 1/(0.5 + 0.5*0.2)
        # rect = Act('elu')
        c = Can()
        c.add(self.create_common_network(inputdims,128))
        c.add(Dense(128,128))
        c.add(rect)
        c.add(Dense(128,outputdims,stddev=1))
        if self.is_continuous:
            c.add(Act('tanh'))
            c.add(Lambda(lambda x: x*self.action_multiplier + self.action_bias))
        else:
            c.add(Act('softmax'))
        c.chain()
        return c
    def train_step_gen(self):
        s1 = tf.placeholder(tf.float32,shape=[None,self.inputdims])
        a_infer = self.actor(s1)
        def joint_inference(state):
            sess = ct.get_session()
            res = sess.run(a_infer,feed_dict={s1:state})
            return res
        return joint_inference
    # one step of action, given observation
    def act(self,observation,curr_noise=None):
        obs = np.reshape(observation,(1,len(observation)))
        actions = self.joint_inference(obs)
        actions = actions[0]
        if curr_noise is not None:
            disp_actions = (actions-self.action_bias) / self.action_multiplier
            disp_actions = disp_actions * 5 + np.arange(self.outputdims) * 12.0 + 30
            noise = curr_noise * 5 - np.arange(self.outputdims) * 12.0 - 30
        
        return actions

    def load_weights(self, episode):
        networks = ['actor']
        for name in networks:
            network = getattr(self,name)
            network.load_weights('./models/ddpg_'+name+str(episode)+'.npz')

#from opensim_rl import OpenSimEnv

if __name__=='__main__':

    from gym.spaces import Box

    from observation_processor import processed_dims
    ob_space = Box(-1.0, 1.0, (processed_dims,))
    action_space = Box(0, 1.0, (18,))

    agent = nnagent(
       processed_dims,
       action_space
    )
    epoch = 237499
    agent.load_weights(epoch)
    
    def up_test():

        apikey = open('apikey.txt').read().strip('\n')
        from client_http import Client as ClientSubmit
        remote_base = "http://127.0.0.1:8000"
        crowdai_token = apikey
        client = ClientSubmit(remote_base)
        client_id = client.env_create(difficulty=2,visualize=False)
        observation = client.env_reset(instance_id=client_id,difficulty=2)
        global stepno
        stepno=0
        epino = 0
        total_reward = 0
        global old_observation
        old_observation = None
        t = 1
        counts = 0
        prev_x = 1.0
        flag = True
        o1 = []
        o2 = []
        o3 = []
        def obg(plain_obs):
            global old_observation, stepno
            processed_observation, old_observation = go(plain_obs, old_observation, step=stepno)
            return np.array(processed_observation)

        print('environment created! running...')
        # Run a single step
        while True:
            proc_observation = obg(observation)
            time.sleep(0.01)
            action = [float(i) for i in list(agent.act(proc_observation))]
            [observation, reward, done, info] = client.env_step(instance_id = client_id,
                action=action
            )
            
            stepno+=1
            total_reward+=reward
            if observation[-3] >=100: 
              #agent.plotter.pushys([0,observation[-2],observation[-1],observation[2]])
              counts += 1
            else:
              #agent.plotter.pushys([observation[-3],observation[-2],observation[-1],observation[2]])
              counts =0
            if counts == 10: 
                agent.load_weights(4500)
                flag=True
            if counts == 0 and flag: 
                agent.load_weights(epoch)
                flag=False
            print('step',stepno,'total reward',total_reward)
            # print(observation)
            if done:
                observation = client.env_reset(instance_id=client_id,difficulty=2)
                old_observation = None

                print('>>>>>>>episode',epino,' DONE after',stepno,'got_reward',total_reward)
                import pdb;pdb.set_trace()
                total_reward = 0
                stepno = 0
                counts = 0
                flag=True
                epino+=1
                o1 = []
                o2 = []
                o3 = []
                if not observation:
                    break

        print('submitting...')
    up_test()
    def up():
        
        apikey = open('apikey.txt').read().strip('\n')

        from client import ClientSubmit
        remote_base = "http://grader.crowdai.org:1729"
        crowdai_token = apikey

        client = ClientSubmit(remote_base)

        observation = client.env_create(crowdai_token)
        # old_observation = None
        global stepno
        stepno= 0
        epino = 0
        total_reward = 0
        global old_observation
        old_observation = None
        flag = True
        t = 1
        prev_x = 1.0
        o1 = []
        o2 = []
        o3 = []
        
        def obg(plain_obs):
            global old_observation, stepno
            processed_observation, old_observation = go(plain_obs, old_observation, step=stepno)
            return np.array(processed_observation)

        counts = 0
        print('environment created! running...')
        # Run a single step
        while True:
            proc_observation = obg(observation)
            time.sleep(0.01)
            [observation, reward, done, info] = client.env_step(
                [float(i) for i in list(agent.act(proc_observation))],
                True
            )
            
            stepno+=1
            total_reward+=reward
            if observation[-3] >=100: 
              #agent.plotter.pushys([0,observation[-2],observation[-1],observation[2]])
              counts += 1
            else:
              #agent.plotter.pushys([observation[-3],observation[-2],observation[-1],observation[2]])
              counts =0
            if counts == 10: 
                agent.load_weights(4500)
                flag=True
            if counts == 0 and flag: 
                agent.load_weights(epoch)
                flag=False
            print('step',stepno,'total reward',total_reward)
            # print(observation)
            if done:
                observation = client.env_reset()
                old_observation = None
                counts = 0
                print('>>>>>>>episode',epino,' DONE after',stepno,'got_reward',total_reward)
                #import pdb;pdb.set_trace()
                total_reward = 0
                stepno = 0
                epino+=1
                o1 = []
                o2 = []
                o3 = []
                if not observation:
                    break

        print('submitting...')
        #import pdb;pdb.set_trace()
        client.submit()

